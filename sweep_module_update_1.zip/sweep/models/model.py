from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
import logging

_logger = logging.getLogger(__name__)


class ProductTempExt(models.Model):
    _inherit = 'product.template'

    is_sweep_product = fields.Boolean(string="Is a Sweep Product")
    sweep_account_id = fields.Many2one('account.account')


class AccountInvoiceExt(models.Model):
    _inherit = 'account.invoice'

    def cron_sweep_entries(self):
        logging.info("Hamza Ilyas ----> cron_sweep_entries called")
        invoices = self.env['account.invoice'].search([('type', '=', 'out_invoice'), ('state', 'in', ('paid', 'open'))])
        for invoice in invoices:
            logging.info("Hamza Ilyas ----> <<<<<<<<<<INVOICE>>>>>>>>>>")
            if invoice.move_id and invoice.invoice_line_ids:

                logging.info("Hamza Ilyas ----> <<<<<<<<<< Invoice Found >>>>>>>>>>")
                for invoice_line in invoice.invoice_line_ids:
                    if not invoice_line.swept:

                        if self.check_ili_in_expenses(invoice_line):
                            self.swept_journal_entry(invoice_line)
                            invoice_line.swept = True
                            continue
                        elif self.check_ili_in_purchase_receipts(invoice_line):
                            self.swept_journal_entry(invoice_line)
                            invoice_line.swept = True
                            continue
                        elif self.check_ili_in_vendor_bills(invoice_line):
                            self.swept_journal_entry(invoice_line)
                            invoice_line.swept = True
                            continue

    def swept_journal_entry(self, invoice_line):
        logging.info("Hamza Ilyas ----> swept_journal_entry Called")
        self.create_swept_journal_entry(invoice_line)

    def create_swept_journal_entry(self, invoice_line):
        logging.info("Hamza Ilyas ----> create_swept_journal_entry Called")
        logging.info("Hamza Ilyas ----> <<<<<<<<<invoice_line.price_unit>>>>>>>>>")
        logging.info(invoice_line.price_unit)
        if invoice_line.product_id.property_account_expense_id:
            account_move_line = self.env['account.move.line']
            # create move
            move = self.env['account.move'].create({'name': invoice_line.invoice_id.number + ' SWEPT',
                                                    'ref': invoice_line.invoice_id.number,
                                                    'journal_id': invoice_line.invoice_id.journal_id.id,
                                                    'state': 'draft',
                                                    'company_id': invoice_line.invoice_id.company_id.id
                                                    })

            move.write({'line_ids': [
                (0, 0, {'account_id': invoice_line.product_id.property_account_expense_id.id,
                        'name': invoice_line.product_id.name,
                        'debit': invoice_line.price_unit,
                        'credit': 0.0,
                        'move_id': move.id,
                        'swept': True,
                        }),
                (0, 0, {'account_id': invoice_line.product_id.sweep_account_id.id,
                        'name': invoice_line.product_id.name,
                        'credit': invoice_line.price_unit,
                        'debit': 0.0,
                        'move_id': move.id,
                        'swept': True,
                        }),
            ], })
            if move:
                move.post()
                logging.info("Hamza Ilyas ----> Swept Journal Entry Created & posted Successfully")

    def check_ili_in_expenses(self, invoice_line):
        logging.info("Hamza Ilyas ----> check_ili_in_expenses Called")
        expenses = self.env['hr.expense'].search([('state', '=', 'done')])
        for expense in expenses:
            if expense.product_id == invoice_line.product_id and \
                    expense.analytic_account_id == invoice_line.account_analytic_id:
                return True
            else:
                continue

    def check_ili_in_purchase_receipts(self, invoice_line):
        logging.info("Hamza Ilyas ----> check_ili_in_purchase_receipts Called")
        purchase_receipts = self.env['account.voucher'].search([('state', '=', 'posted')])
        for receipt in purchase_receipts:
            for receipt_line in receipt.line_ids:
                if receipt_line.product_id == invoice_line.product_id and \
                        receipt_line.account_analytic_id == invoice_line.account_analytic_id:
                    return True
                else:
                    continue

    def check_ili_in_vendor_bills(self, invoice_line):
        logging.info("Hamza Ilyas ----> check_ili_in_vendor_bills Called")
        vendor_bills = self.env['account.invoice'].search([('state', 'in', ('paid', 'open')), ('type', '=', 'in_invoice')])
        for bill in vendor_bills:
            for bill_line in bill.invoice_line_ids:
                if bill_line.product_id == invoice_line.product_id and \
                        bill_line.account_analytic_id == invoice_line.account_analytic_id:
                    return True
                else:
                    continue


class AccountInvoiceLineExt(models.Model):
    _inherit = 'account.invoice.line'

    swept = fields.Boolean("Swept")

    @api.onchange('product_id')
    def onchange_product_id(self):
        logging.info("Hamza Ilyas ----> onchange_product_id Called on account invoice line")
        if self.invoice_id.type == 'in_invoice':
            if self.product_id:
                if self.product_id.is_sweep_product:
                    self.account_id = self.product_id.sweep_account_id


class HrExpenseExt(models.Model):
    _inherit = 'hr.expense'

    @api.onchange('product_id')
    def onchange_product_id(self):
        logging.info("Hamza Ilyas ----> onchange_product_id Called on hr.expense")
        if self.product_id:
            if self.product_id.is_sweep_product:
                self.account_id = self.product_id.sweep_account_id


class AccountVoucherExt(models.Model):
    _inherit = 'account.voucher.line'

    # @api.model
    # def create(self, vals):
    #     if 'product_id' in vals:
    #         if vals['product_id']:
    #             product = self.env['product.product'].search([('id', '=', vals['product_id'])])
    #             if product:
    #                 if product.is_sweep_product and product.sweep_account_id:
    #                     vals['account_id'] = product.sweep_account_id.id
    #
    #     rec = super(AccountVoucherExt, self).create(vals)
    #     return rec

    #@api.multi
    # def write(self, vals):
    #     return super(AccountVoucherExt, self).write(vals)

    @api.onchange('product_id')
    def onchange_product_id(self):
        logging.info("Hamza Ilyas ----> onchange_product_id Called on account voucher line")
        if self.product_id:
            temp = self.product_id
            self.product_id = self.env['product.product'].search([])[1]
            self.product_id = temp
            if self.product_id.is_sweep_product:
                logging.info("Hamza Ilyas ----> is_sweep_product")
                self.account_id = self.product_id.sweep_account_id.id
                self.write({
                    'account_id': self.product_id.sweep_account_id.id
                })
                self.account_id = self.product_id.sweep_account_id.id
                logging.info("Hamza Ilyas ----> account_id set as :")
                logging.info(self.account_id.name)
                # self.check_account_id(self.product_id, self.account_id)

    def check_account_id(self, product_id, account_id):
        logging.info("Hamza Ilyas ----> check_account_id Called")
        if product_id.is_sweep_product and product_id.sweep_account_id:
            logging.info("11")
            if product_id.sweep_account_id.id != account_id.id:
                logging.info("22")
                self.onchange_product_id()
                logging.info("Hamza Ilyas ----> finish check_account_id")


class SweepJournal(models.Model):
    _name = 'sweep.journal'

    journal_id = fields.Many2one('account.journal', string='Journal')


class AccountMoveLineExt(models.Model):
    _inherit = 'account.move.line'

    swept = fields.Boolean(string="Swept", readonly=True)


class AccountMoveExt(models.Model):
    _inherit = 'account.move'

    @api.multi
    def button_cancel(self):
        logging.info("Hamza Ilyas ----> button_cancel Called")
        for move in self:
            if not move.journal_id.update_posted:
                raise UserError(
                    _('You cannot modify a posted entry of this journal.\nFirst you should set the journal to allow cancelling entries.'))
            else:
                for line in move.line_ids:
                    line.swept = False
        if self.ids:
            self.check_access_rights('write')
            self.check_access_rule('write')
            self._check_lock_date()
            self._cr.execute('UPDATE account_move ' \
                             'SET state=%s ' \
                             'WHERE id IN %s', ('draft', tuple(self.ids),))
            self.invalidate_cache()
        self._check_lock_date()
        return True
